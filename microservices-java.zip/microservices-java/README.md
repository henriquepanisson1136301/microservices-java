# microservices-java
Projeto de Microservices em Java utilizando Spring Boot
