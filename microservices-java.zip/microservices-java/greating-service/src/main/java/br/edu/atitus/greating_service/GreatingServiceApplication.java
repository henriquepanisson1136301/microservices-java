package br.edu.atitus.greating_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreatingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreatingServiceApplication.class, vargs);
	}

}
